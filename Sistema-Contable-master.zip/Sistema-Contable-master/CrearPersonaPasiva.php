<?php
include("Conexion.php");



	$Codigo=$_POST['codigo_persona'];

    $Dia=$_POST['dia'];
	$Mes=$_POST['mes'];
	$Gestion=$_POST['gestion'];
	
	$MesOrigen="";
	if($Mes == 'Enero')
	{$MesOrigen='01';}
	if($Mes == 'Febrero')
	{$MesOrigen='02';}
	if($Mes == 'Marzo')
	{$MesOrigen='03';}
	if($Mes == 'Abril')
	{$MesOrigen='04';}
	if($Mes == 'Mayo')
	{$MesOrigen='05';}
	if($Mes == 'Junio')
	{$MesOrigen='06';}
	if($Mes == 'Julio')
	{$MesOrigen='07';}
	if($Mes == 'Agosto')
	{$MesOrigen='08';}
	if($Mes == 'Septiembre')
	{$MesOrigen='09';}
	if($Mes == 'Octubre')
	{$MesOrigen='10';}
	if($Mes == 'Noviembre')
	{$MesOrigen='11';}
	if($Mes == 'Diciembre')
	{$MesOrigen='12';}
	
	$Fecha=$Gestion."-".$MesOrigen."-".$Dia;

	$consulta=$cn->prepare('INSERT INTO persona_pasiva(codigo_persona,fecha_visita)VALUES(:Codigo,:Fecha)');
	$consulta->execute(array(':Codigo'=>$Codigo,':Fecha'=>$Fecha));
	$resultado=$consulta->fetch();

?>