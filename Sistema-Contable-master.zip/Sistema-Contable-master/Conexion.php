<?php
$cn = new PDO('mysql:host=localhost;dbname=sistema contable', 'root', '');

/*if($con)
{echo "<script>alert('La conexion fue exitosa');</script>";}
else
{echo "<script>alert('La conexion fallo');</script>";}*/

?>





